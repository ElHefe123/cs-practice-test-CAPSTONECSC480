# Changelog

## 0.1.0 - Initial prototype
- Added two sample multiple-choice practice tests.
- Added automatic scoring and answer review.
- Added unanswered-question validation.
- Added project documentation and release checklist.
