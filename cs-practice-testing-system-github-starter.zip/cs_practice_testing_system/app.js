const questionSets = {
  fundamentals: [
    { q: "Which component executes instructions in a computer?", options: ["CPU", "Monitor", "Keyboard", "Printer"], answer: 0, explanation: "The CPU processes instructions and coordinates operations." },
    { q: "Which data structure follows first-in, first-out order?", options: ["Stack", "Queue", "Tree", "Graph"], answer: 1, explanation: "A queue removes items in the same order they were added." },
    { q: "What is the primary purpose of testing software?", options: ["Guarantee zero defects", "Find defects and evaluate behavior", "Replace documentation", "Avoid user feedback"], answer: 1, explanation: "Testing provides evidence about quality and can reveal defects; it cannot prove a system is defect-free." },
    { q: "Which number is binary for decimal 2?", options: ["01", "10", "11", "100"], answer: 1, explanation: "Binary 10 represents (1 × 2) + (0 × 1), which equals decimal 2." },
    { q: "What does an algorithm describe?", options: ["A step-by-step method for solving a problem", "A physical storage device", "A programming language only", "A network cable"], answer: 0, explanation: "An algorithm is a finite sequence of steps for solving a problem." }
  ],
  programming: [
    { q: "Which construct repeats a block of code?", options: ["Loop", "Comment", "Variable name", "Import statement only"], answer: 0, explanation: "Loops repeat instructions while a condition or iteration rule applies." },
    { q: "What is a variable commonly used for?", options: ["Store a value", "Compile the operating system", "Connect a monitor", "Encrypt every file automatically"], answer: 0, explanation: "Variables name storage locations or values used by a program." },
    { q: "What is a Boolean value?", options: ["A true-or-false value", "A decimal-only number", "A file extension", "A type of loop"], answer: 0, explanation: "Boolean values represent truth states, usually true and false." },
    { q: "What is a function?", options: ["A reusable block of code", "A computer screen", "A database backup only", "A hardware port"], answer: 0, explanation: "Functions package behavior that can be called when needed." },
    { q: "What should a program do when required input is missing?", options: ["Silently report success", "Handle it safely and explain the issue", "Delete unrelated data", "Ignore all validation"], answer: 1, explanation: "Clear validation and error handling help prevent invalid operations." }
  ]
};

const testSelect = document.querySelector("#test-select");
const startButton = document.querySelector("#start-btn");
const quizPanel = document.querySelector("#quiz-panel");
const resultsPanel = document.querySelector("#results-panel");
const questionsNode = document.querySelector("#questions");
const progressNode = document.querySelector("#progress");
const messageNode = document.querySelector("#form-message");
const quizForm = document.querySelector("#quiz-form");
let activeQuestions = [];

function startTest() {
  activeQuestions = questionSets[testSelect.value] || [];
  questionsNode.replaceChildren();
  messageNode.textContent = "";
  resultsPanel.hidden = true;
  quizPanel.hidden = false;

  activeQuestions.forEach((question, index) => {
    const fieldset = document.createElement("fieldset");
    fieldset.className = "question";
    const legend = document.createElement("legend");
    legend.textContent = `${index + 1}. ${question.q}`;
    fieldset.append(legend);

    question.options.forEach((option, optionIndex) => {
      const label = document.createElement("label");
      label.className = "option";
      const input = document.createElement("input");
      input.type = "radio";
      input.name = `question-${index}`;
      input.value = String(optionIndex);
      input.required = true;
      const span = document.createElement("span");
      span.textContent = option;
      label.append(input, span);
      fieldset.append(label);
    });
    questionsNode.append(fieldset);
  });
  progressNode.textContent = `${activeQuestions.length} questions`;
  quizPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

function gradeTest(event) {
  event.preventDefault();
  const formData = new FormData(quizForm);
  const unanswered = activeQuestions.filter((_, index) => !formData.has(`question-${index}`));
  if (unanswered.length) {
    messageNode.textContent = `Please answer all questions before submitting. ${unanswered.length} unanswered.`;
    const firstMissing = activeQuestions.findIndex((_, index) => !formData.has(`question-${index}`));
    questionsNode.querySelectorAll("fieldset")[firstMissing]?.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }

  let correctCount = 0;
  const review = document.querySelector("#review");
  review.replaceChildren();
  activeQuestions.forEach((question, index) => {
    const selected = Number(formData.get(`question-${index}`));
    const isCorrect = selected === question.answer;
    if (isCorrect) correctCount += 1;
    const item = document.createElement("article");
    item.className = "review-item";
    const heading = document.createElement("p");
    heading.className = isCorrect ? "correct" : "incorrect";
    heading.textContent = `${index + 1}. ${isCorrect ? "Correct" : "Incorrect"} — ${question.q}`;
    const answer = document.createElement("p");
    answer.textContent = `Correct answer: ${question.options[question.answer]}`;
    const explanation = document.createElement("p");
    explanation.className = "muted";
    explanation.textContent = question.explanation;
    item.append(heading, answer, explanation);
    review.append(item);
  });

  const percent = Math.round((correctCount / activeQuestions.length) * 100);
  document.querySelector("#score").textContent = `Score: ${correctCount} out of ${activeQuestions.length} (${percent}%)`;
  quizPanel.hidden = true;
  resultsPanel.hidden = false;
  resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

startButton.addEventListener("click", startTest);
quizForm.addEventListener("submit", gradeTest);
document.querySelector("#reset-btn").addEventListener("click", startTest);
document.querySelector("#retry-btn").addEventListener("click", () => {
  resultsPanel.hidden = true;
  startTest();
});
