# Online Computer Science Practice Testing System

A small web-based prototype for introductory computer science practice tests. Students can select a quiz, answer multiple-choice questions, submit responses, and review an automatically calculated score.

## Project status
Educational capstone prototype. This is a client-side demonstration and does not yet include secure accounts, a server, or a database. Do not use real student information.

## Features
- Select an introductory computer science practice test
- Answer multiple-choice questions
- Submit a test and calculate a score
- Review correct answers and explanations
- Responsive layout for desktop and mobile browsers
- Basic handling for unanswered questions

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Select a practice test, answer the questions, and select **Submit test**.

No build tools or dependencies are required.

## Repository structure
```text
cs-practice-testing-system/
├── index.html
├── styles.css
├── app.js
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
├── .gitignore
└── docs/
    ├── scm-plan.md
    ├── test-plan.md
    └── release-checklist.md
```

## Suggested GitHub workflow
1. Create a repository named `cs-practice-testing-system`.
2. Upload these files, keeping the folder structure shown above.
3. Commit the initial version with message: `Initial practice testing system prototype`.
4. Create feature branches for changes, such as `feature/add-questions`.
5. Test changes before merging them into `main`.
6. Use version tags such as `v0.1.0` for releases.

## Planned future improvements
- Backend API and database persistence
- Secure authentication and role-based access
- Administrator interface for managing questions
- Automated unit and integration tests
- Accessibility review and stronger input validation
