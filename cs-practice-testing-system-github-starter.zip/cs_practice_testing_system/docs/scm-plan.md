# Software Configuration Management Plan

## Purpose and scope
This plan describes how project files for the Online Computer Science Practice Testing System will be identified, changed, reviewed, versioned, and recovered. Git provides local version control and GitHub provides a shared repository for the capstone prototype.

## Configuration items
The controlled items include HTML, CSS, JavaScript, README and contributor documentation, test plans, release checklists, and project history. Generated files, editor settings, credentials, and real student data should not be committed.

## Version control and branching
The `main` branch represents the latest reviewed version. Each new feature or fix should use a short-lived branch such as `feature/add-question-bank` or `fix/unanswered-validation`. Commits should be small and describe one logical change. Pull requests should explain the purpose, files changed, and tests completed. Changes should be reviewed before merging.

## Verification and release
Before merging, verify that the application opens in a modern browser, each quiz loads, all questions can be answered, unanswered questions are rejected with a clear message, scores are calculated correctly, and results show the correct answers. Record significant changes in `CHANGELOG.md`. Tag approved milestones with semantic version labels such as `v0.1.0`.

## Backup and recovery
The remote GitHub repository is a shared copy of the project history, but it should not be treated as the only backup. Keep a local clone and periodically export or back up the repository. To undo a public change, prefer a new `git revert` commit so history remains auditable. For accidental local changes, inspect `git status` and review the diff before restoring files.

## Security and risks
Never commit credentials, access tokens, private student data, or database exports. Use repository permissions appropriate to collaborators and enable multi-factor authentication on the GitHub account. Risks include unreviewed changes, lost work, accidental secrets, and incompatible versions. Branch protection, code review, testing, and backups reduce these risks.

## Responsibilities
The project owner maintains repository access, reviews changes, confirms tests, prepares releases, and updates documentation. For a team project, each contributor is responsible for testing and documenting their own changes.
