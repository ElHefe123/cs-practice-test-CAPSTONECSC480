# Draft Software Test Plan

## Objective
Confirm that the prototype loads practice tests, validates answers, calculates scores, and presents useful feedback.

## Test cases

### TC-01: Start a fundamentals test
Input: Select “Computer Science Fundamentals” and click “Start test.”
Expected result: Five questions and answer choices appear.

### TC-02: Start a programming test
Input: Select “Programming Basics” and click “Start test.”
Expected result: The five programming questions appear.

### TC-03: Submit all correct answers
Input: Select the correct answer for every question and submit.
Expected result: The score displays 100%, with each answer marked correct.

### TC-04: Submit a mixed set of answers
Input: Answer some questions correctly and some incorrectly.
Expected result: The score equals correct answers divided by total questions, rounded to a whole percent. Each correct answer and explanation appears in review.

### TC-05: Submit with unanswered questions
Input: Leave at least one question blank and submit.
Expected result: Submission is blocked and a message reports how many questions remain unanswered.

### TC-06: Restart the test
Input: Click “Start over” while taking a test.
Expected result: The selected test reloads without carrying forward previous selections.

### TC-07: Switch tests after viewing results
Input: Finish a test, choose the other test, and click “Start test.”
Expected result: The new test is shown and previous results are not displayed as if they belonged to the new test.

## Testing methods
Functional testing checks the expected user flows. Boundary and negative testing checks incomplete submissions and unexpected user actions. Manual regression testing repeats key flows after code changes. Unit and integration tests should be added when the application is separated into testable modules and services.

## Performance expectations
For this small client-side prototype on a typical current computer, the page should become usable within about two seconds on a normal connection, and score calculation should appear within one second after submission. These are target expectations, not measured results. A future server-backed version should test concurrent users and database response times.

## Known limitations
The prototype has no persistent storage, authentication, server-side validation, administrator tools, or automated test suite. Results disappear when the page is refreshed. Those features require additional implementation and testing before production use.
