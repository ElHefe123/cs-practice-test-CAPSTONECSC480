# Release Checklist

- [ ] Confirm all files are committed and the working tree is clean.
- [ ] Open `index.html` in a current browser.
- [ ] Verify both test choices load the correct questions.
- [ ] Verify all-correct answers produce 100%.
- [ ] Verify mixed answers produce the expected percentage.
- [ ] Verify unanswered questions block submission.
- [ ] Verify restart clears previous answers.
- [ ] Check keyboard navigation and focus visibility.
- [ ] Review changes for accidental credentials or private data.
- [ ] Update `CHANGELOG.md`.
- [ ] Tag the reviewed release (for example, `v0.1.0`).
