# Contributing

1. Create a feature branch from `main`.
2. Make a focused change and use clear, descriptive names.
3. Test the relevant user flow in a modern browser.
4. Check keyboard navigation and readable error messages.
5. Open a pull request describing the change and tests performed.
6. Merge only after review and successful checks.

Use commit messages such as `Add boundary case for unanswered questions` or `Improve results review layout`. Never commit passwords, API keys, or real student information.
